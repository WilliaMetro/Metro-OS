Welcome to Metro os
by Metro Studio :)
CMD support DOS support python support
well you can see :) 
this is python Scrip :)
so you can see file and folder :)

you can run code:
Windows:
you need python to run, if you have python double click it'll run

Linux:
you need python to run, if you have python go to terminal
and insert:
chmod +x metro-os.py
./ metro-os.py
it'll run

[G] 
[metro-os.py] 
[os test] 
[README.txt] 
[z(wwindow) code.txt]
[z(python) code.txt]
[z(python-gui) code.txt]

 ok you can run [metro-os.py]

ok system file is [G]
[Z] is code in text file :) 
good luck 

in BOOT MENU you can type cdrom and devmode 

cdrom doesn't have password
devmode have password it's my birthday and you can check the code if you are a coder 
well enjoy



