Welcome to Metro os
by Metro Studio :)
CMD support DOS support 
well you can see :) 
this is Batch Scrip :)
so you can see file and folder :)

[beta] 
[G] 
[Metro.bat] 
[os test] 
[read me.txt] 
[Z]
 ok you can run [os test]  or [Metro.bat]

ok system file is [G]
and beta version is [beta]
[Z] is code in text file :) 
good luck 

in BOOT MENU you can type cdrom and devmode 

cdrom doesn't have password
devmode have password it's my birthday and you can check the code if you are a coder 
well enjoy

